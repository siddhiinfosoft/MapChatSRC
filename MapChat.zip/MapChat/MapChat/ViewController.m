//
//  ViewController.m
//  MapChat
//
//  Created by Vishal Tanna on 27/05/16.
//  Copyright © 2016 SiddhiInfosoft. All rights reserved.
//

#import "ViewController.h"
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKShareKit/FBSDKShareKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>

#import <GoogleOpenSource/GoogleOpenSource.h>
#import <GooglePlus/GooglePlus.h>


@interface ViewController ()

@end

@implementation ViewController
@synthesize signInButton;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    appDel=[UIApplication sharedApplication].delegate;
    web=[[WebService alloc]init];
    web.delegate=self;
    tabBarController=[[TabBarController alloc]init];
    
    signin=[GPPSignIn sharedInstance];
    signin.shouldFetchGooglePlusUser=YES;
    signin.shouldFetchGoogleUserEmail=YES;
    signin.shouldFetchGoogleUserID=YES;
    signin.clientID=s;
    signin.scopes=@[kGTLAuthScopePlusLogin,@"profile",kGTLAuthScopePlusMe];
    signin.delegate=self;
    
    [signin trySilentAuthentication];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated
{
    if (appDel.str_user_id.length>0)
    {
        //Navigate To home page
        
        
        
        
    }
}

#pragma mark-Facebook button 
- (IBAction)btnFacebookAction:(UIButton *)sender
{
    [appDel.cmn showProgressHudWithView:self.view];
    appDel.str_For_fb_Google_Twitter=@"fb";
    FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];

    [login logInWithReadPermissions:@[@"public_profile",@"email",@"user_photos",@"user_friends"]
                            handler:^(FBSDKLoginManagerLoginResult *result,NSError *error)
     {
         if(error)
         {
             [appDel.cmn hideProgressHudWithView:self.view];
             NSLog(@"Error in Login Button:%@",error);
         }
         else if (result.isCancelled)
         {
             [appDel.cmn hideProgressHudWithView:self.view];
             NSLog(@"Result is Cancelled");
         }
         else
         {
             NSLog(@"Login");
             Facebook_Status=YES;
             [self retrieveinformation];
         }
         
     }
     ];
    
    
}


- (void)  loginButton:(FBSDKLoginButton *)loginButton
didCompleteWithResult:(FBSDKLoginManagerLoginResult *)result
                error:(NSError *)error
{
    
    if (error !=nil)
    {
        NSLog(@"%@",result);
    }
}

- (void) loginButtonDidLogOut:(FBSDKLoginButton *)loginButton
{
    
}

- (BOOL) loginButtonWillLogin:(FBSDKLoginButton *)loginButton
{
    return YES;
}



-(void)retrieveinformation
{
    if ([FBSDKAccessToken currentAccessToken]) {
        [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:@{@"fields":@"first_name,last_name,gender,email,picture.type(large)"}]startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error)
         {
             NSLog(@"Result:%@",result);
            if (!error)
            {
                appDel.str_For_fb_Google_Twitter=@"fb";
                appDel.str_stype=@"fb";
                NSLog(@"%@",result);
                
                NSDictionary *dict_Result=(NSDictionary*)result;
                [self dataRetrieveFromFB:dict_Result];
            }
            else
            {
                [appDel.cmn hideProgressHudWithView:self.view];
                NSLog(@"%@",error);
            }
        }];
    }
    
}
-(void)dataRetrieveFromFB:(NSDictionary *)dict
{
    
    appDel.str_first_name=[dict objectForKey:@"first_name"];
    appDel.str_last_name=[dict objectForKey:@"last_name"];
    appDel.str_email=[dict objectForKey:@"email"];
    appDel.str_Profile_pic=[[[dict objectForKey:@"picture"] objectForKey:@"data"] objectForKey:@"url"];
    appDel.str_stype=@"fb";
    
    [self loadRequest];
}

#pragma mark-Twitter button
- (IBAction)btnTwitterAction:(UIButton *)sender
{
    
    appDel.str_For_fb_Google_Twitter=@"twitter";
    [self signInWithTwitter];
    [self.navigationController.navigationBar setHidden:YES];
    
    
}

-(void)signInWithTwitter
{
    self.accountsStore=[[ACAccountStore alloc]init];
    ACAccountType *twitterAccountType=[self.accountsStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
    [self.accountsStore requestAccessToAccountsWithType:twitterAccountType
                                                options:nil
                                             completion:^(BOOL granted, NSError *error) {
                                                 dispatch_async(dispatch_get_main_queue(), ^{
                                                     if (granted)
                                                     {
                                                         
                                                         NSLog(@"Granted!");
                                                         ACAccount *account = [[self.accountsStore accountsWithAccountType:twitterAccountType] lastObject];
                                                         
                                                         if(!account && ![[account valueForKey:@"properties"] valueForKey:@"user_id"])
                                                         {
                                                             
                                                             UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Alert" message:@"Sorry, No twitter account is configured. Please configure twitter account from settings." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:@"Cancel",nil];
                                                             alert.tag=0;
                                                             [alert show];
                                                             
                                                             //  [SVProgressHUD dismissWithError:@""];
                                                         }
                                                         else
                                                         {
                                                             NSMutableDictionary *objDict=[[NSMutableDictionary alloc]init];
                                                             [objDict setObject:account forKey:@"twitteraccoutn"];
                                                             
                                                             NSString *urlString = [NSString stringWithFormat:@"https://api.twitter.com/1.1/users/show.json?screen_name=%@",account.username];
                                                             NSURL *statusURL = [[NSURL alloc]initWithString:urlString];
                                                             SLRequest *request1 = [SLRequest requestForServiceType:SLServiceTypeTwitter
                                                                                                      requestMethod:SLRequestMethodGET
                                                                                                                URL:statusURL
                                                                                                         parameters:nil];
                                                             request1.account = account;
                                                             [request1 performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error) {
                                                                 
                                                                 dispatch_async(dispatch_get_main_queue(), ^{
                                                                     if (responseData)
                                                                     {
                                                                         NSDictionary *statusData = [NSJSONSerialization JSONObjectWithData:responseData
                                                                                                                                    options:NSJSONReadingAllowFragments
                                                                                                                                      error:nil];
                                                                         NSLog(@"Twitter Friends Response : %@",statusData);
                                                                         
                                                                         if (statusData.count!=0)
                                                                         {
                                                                             
                                                                            appDel.str_Profile_pic=[statusData objectForKey:@"profile_image_url"];
                                                                             
                                                                             NSLog(@"%@",[statusData objectForKey:@"profile_image_url"]);
                                                                             appDel.str_first_name=[statusData objectForKey:@"name"];
                                                                             
                                                                             NSLog(@"%@",[statusData objectForKey:@"name"]);
                                                                             
                                                                             NSUserDefaults *defaultss=[NSUserDefaults standardUserDefaults];
                                                                             NSLog(@"Twitter Account User Name : %@",account.username);
                                                                             
                                                                            appDel.str_username=account.username;
                                                                             
                                                                             
                                                                             NSLog(@"Twitter Account FullName : %@",account.userFullName);
                                                                             
                                                                             
                                                                             
                                                                             NSLog(@"%@",[statusData objectForKey:@"profile_image_url"]);
                                                                             
                                                                    appDel.str_stype=@"tw";
                                                                             
                                                                             [self loadRequest];
                                                                         }
                                                                         else
                                                                         {
                                                                             //  [SVProgressHUD  dismiss];
                                                                         }
                                                                         
                                                                     }
                                                                 });
                                                             }];
                                                             
                                                         }
                                                         
                                                     }
                                                     else
                                                     {
                                                         NSLog(@"No permission :(  %@", error);
                                                         UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Alert" message:@"Sorry, permission to access twitter accounts is not granted. Please grant permission from settings." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:@"Cancel", nil];
                                                         [alert show];
                                                         // [SVProgressHUD dismissWithError:@""];
                                                     }
                                                 });
                                             }];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==0) //For Twitter
    {
        if (buttonIndex==0)
        {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"prefs:root=TWITTER"]];
        }
    }
    else if(alertView.tag==1)
    {
        if (buttonIndex==0)
        {
            //Navigate To Home Page
            
            
        }
    }
    
    
   
}


#pragma mark-Googleplus button
- (IBAction)btnGplusAction:(UIButton *)sender
{
    appDel.str_For_fb_Google_Twitter=@"gmail";
    
//    signin=[[GPPSignIn alloc]init];
//    signin = [GPPSignIn sharedInstance];
//    signin.shouldFetchGooglePlusUser = YES;
//    
//    signin.clientID =s;
//
//    signin.scopes = @[ kGTLAuthScopePlusLogin ];
//    signin.scopes = @[ @"profile" ];
//    signin.delegate = self;
//    
////    [signin trySilentAuthentication];
//    [signin authentication];
    
    
}




- (void)finishedWithAuth: (GTMOAuth2Authentication *)auth
                   error: (NSError *) error {
    NSLog(@"Received error %@ and auth object %@",error, auth);
    if (error) {
        // Do some error handling here.
    } else {
        
        NSLog(@"%@",signin.userEmail);
    }
}

- (void)signOut {
    [[GPPSignIn sharedInstance] signOut];
}



#pragma mark-LoadRequest & Parameters

-(void)loadRequest
{
    [appDel.cmn showProgressHudWithView:self.view];
    [self loadDataInDictionary];
    [web sendRequestWithDataDict:parameters andActionString:@"sociallogin"];
}

-(void)loadDataInDictionary
{

    parameters=[[NSMutableDictionary alloc]init];
    
    if ([appDel.str_stype isEqualToString:@"fb"])
    {
        [parameters setObject:appDel.str_first_name forKey:@"first_name"];
        [parameters setObject:appDel.str_last_name forKey:@"last_name"];
        [parameters setObject:appDel.str_email forKey:@"email"];
        [parameters setObject:appDel.str_stype forKey:@"stype"];
        
        
        NSURL *url = [NSURL URLWithString:appDel.str_Profile_pic];
        NSData *data = [NSData dataWithContentsOfURL:url];
        UIImage *img = [[UIImage alloc] initWithData:data];
        NSMutableArray *arr_image=[[NSMutableArray alloc]init];
        [arr_image addObject:img];
        [parameters setObject:arr_image forKey:@"file"];
    }
    
    if ([appDel.str_stype isEqualToString:@"tw"])
    {
        NSURL *url = [NSURL URLWithString:appDel.str_Profile_pic];
        NSData *data = [NSData dataWithContentsOfURL:url];
        UIImage *img = [[UIImage alloc] initWithData:data];
        NSMutableArray *arr_image=[[NSMutableArray alloc]init];
        [arr_image addObject:img];
        [parameters setObject:arr_image forKey:@"file"];
        
        [parameters setObject:img forKey:@"file"];
        [parameters setObject:appDel.str_first_name forKey:@"first_name"];
        [parameters setObject:appDel.str_username forKey:@"username"];
    }
}




#pragma mark --- webservice Delegate---
-(void)onFinishLodingWithDictionary:(NSMutableDictionary*)dict
{
    
    
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    
       if([[dict valueForKey:@"success"] isEqualToString:@"true"])
        {
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[dict valueForKey:@"message"]
                                                            message:@""
                                                           delegate:self
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil];
            [alert show];
            alert.tag=1;
            
            //Store UserInfoInTo NsuserDefault
            NSDictionary *dict_For_Default=[NSDictionary dictionaryWithDictionary:dict];
            
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            [defaults setObject:dict_For_Default forKey:@"User_Register_Info"];
            [defaults synchronize];
            
        }
    
       else
       {
           UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[dict valueForKey:@"message"]
                                                        message:@""
                                                       delegate:nil
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil];
           [alert show];
    }
}
-(void)onFinishLodingWithError:(NSString*)error
{
    NSLog(@"%@",[error description]);
}

#pragma mark---Navigate TabBarController---
-(void)navigateToTabBarController
{
    //navigate to Login Page
    UIStoryboard *objStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    tabBarController = [objStoryboard instantiateViewControllerWithIdentifier:@"TabBarController"];
    [self.navigationController pushViewController:tabBarController animated:YES];
}
@end
