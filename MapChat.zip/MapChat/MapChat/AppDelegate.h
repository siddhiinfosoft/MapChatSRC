//
//  AppDelegate.h
//  MapChat
//
//  Created by Vishal Tanna on 27/05/16.
//  Copyright © 2016 SiddhiInfosoft. All rights reserved.
//

/*
 Notes:
 
 --> NSUserDefault
 
User_Register_Info   //For Storing User Register and Login Inforamtion
 
 
 
 */



#import <UIKit/UIKit.h>
#import "Common.h"
#import "Reachability.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
}
@property (strong, nonatomic) UIWindow *window;
@property (retain, nonatomic) Common *cmn;

//user's Data
@property (strong,nonatomic)NSString *str_username;
@property (strong,nonatomic)NSString *str_first_name;
@property (strong,nonatomic)NSString *str_last_name;
@property (strong,nonatomic)NSString *str_email;
@property (strong,nonatomic)NSString *str_Profile_pic;
@property (strong,nonatomic)NSString *str_stype;
@property(strong,nonatomic)NSString *str_user_id;
//Registration Screen
@property (strong,nonatomic) NSString *str_For_fb_Google_Twitter;



//For Facebook 


@end

