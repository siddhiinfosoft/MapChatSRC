//
//  ViewController.h
//  MapChat
//
//  Created by Vishal Tanna on 27/05/16.
//  Copyright © 2016 SiddhiInfosoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import "AppDelegate.h"

#import <GooglePlus/GooglePlus.h>
static NSString *const s=@"347987979175-8128hp2b2kj3ofavvj5gnnda0vf5hdnk.apps.googleusercontent.com";

//Twitter Account
#import <Accounts/Accounts.h>
#import <Social/Social.h>
#import <Twitter/Twitter.h>
#import <Foundation/Foundation.h>
#import "WebService.h"
#import "TabBarController.h"
@class GPPSignInButton;
@interface ViewController : UIViewController<FBSDKLoginButtonDelegate,GPPSignInDelegate,UIAlertViewDelegate,WebServiceDelegate>
{
    //Class Refrence
    AppDelegate *appDel;
    WebService *web;
    TabBarController *tabBarController;
    
    bool Facebook_Status;
    
    IBOutlet UIButton *btnFacebook;
    GPPSignIn *signin;
    
    
    
    
    //For Twitter
    ACAccount *facebookAccount;
    NSMutableDictionary *objTwitterSecondpassDict;
    
    NSMutableDictionary *parameters;
   
    
    
    IBOutlet UIImageView *imageview;
}

@property (nonatomic,strong)ACAccountStore *accountsStore;
@property (nonatomic,strong)NSMutableDictionary *objTwitterSecondpassDict;
@property (strong, nonatomic) IBOutlet GPPSignInButton *signInButton;
@end

