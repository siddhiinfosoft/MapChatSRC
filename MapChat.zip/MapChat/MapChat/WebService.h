//
//  WebService.h
//  WebserviceExmpleWithNotification
//
//  Created by kushal shah on 12/15/12.
//  Copyright (c) 2012 Techfreak Developers. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "ASIHTTPRequest.h"
#import "Common.h"


@protocol WebServiceDelegate <NSObject>
@required
-(void)onFinishLodingWithDictionary:(NSMutableDictionary*)dict;
-(void)onFinishLodingWithError:(NSString*)error;
@end

@interface WebService : NSObject<ASIHTTPRequestDelegate>
{

    NSMutableData *data;
    NSMutableDictionary *resultDict;
    id <WebServiceDelegate> delegate;
    //mitul -16-5-2016 12:48
    NSMutableArray *arr_attachment_name;
}
@property(retain,nonatomic)NSMutableData *data;
@property(retain,nonatomic)NSMutableDictionary *resultDict;
-(void)sentRequestWithURlString:(NSString*)str;
-(void)sendRequestWithDataDict:(NSMutableDictionary*)dataDict andActionString:(NSString*)action;

//-(void)uploadPhotoWithDataDict:(NSMutableDictionary*)dict andActionString:(NSString*)action;


-(BOOL) validateEmail: (NSString *) email;
-(NSString*)convertDateFormateFormCurrentFormate:(NSString*)currentFormate toNewFormate:(NSString*)newFormate withDate:(NSString*)dateString;
-(NSString *) stringByStrippingHTMLWithString:(NSString*)str;
-(NSString *)convertHtmltoPlainText:(NSString *)String;
-(NSString *)convertPlainTextToHtmlTag:(NSString*)str;
@property (retain) id delegate;

-(BOOL)isNullObject:(NSString*)str;
@end
