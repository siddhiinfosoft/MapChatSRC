//
//  Common.h
//  JoomSocial
//
//  Created by Lion User on 22/02/2013.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//


#define commonUrl @"http://siddhidevelopment.com/mapchat/index.php?option=com_mapchat&task=%@"


//administrator

#define imageUrl @"http://siddhiinfosoft.com/developers/jiruuapp/"
#define profileImageUrl @"http://192.168.1.21/megatropolimx/"

#define userDefualtImageUrl @"http://192.168.1.21/megatropolimx/wp-webs/assets/default_images/user/user_default_image.jpeg"

#define catPage 10
#define subCatPage 10
#import <UIKit/UIKit.h>
//#import "Constant.h"
//#import "ProfileVC.h"

#import "MBProgressHUD.h"
@interface Common : UIViewController<MBProgressHUDDelegate>
{
    MBProgressHUD *hud;
    NSMutableArray *selectedSubcategoryArray;
    NSMutableDictionary *fbDict;
    
    UIImageView *imgLogo;
    UIImage *mygif;
}

@property (retain,nonatomic)NSMutableDictionary *fbDict;
@property (retain,nonatomic)NSMutableArray *selectedSubcategoryArray;
@property (retain,nonatomic)MBProgressHUD *hud;
-(void)addLogoutButtonToNavigationController:(UINavigationItem*)nav;
-(void)showProgressHudWithView:(UIView*)view;
-(void)hideProgressHudWithView:(UIView*)view;
-(void)addSlectedCategoryDataToArray:(int)parentId;
-(int)getLastSelectedIdOfSubCategory;
-(void)updateScreenSize;
-(UIColor*)setColorWithRGBAWithValuesOfRed:(CGFloat)Red andGreen:(CGFloat)green andBlue:(CGFloat)blue andAlpha:(CGFloat)alpha;

-(NSString *)convertHtmltoPlainText:(NSString *)String;
-(NSString *) stringByStrippingHTMLWithString:(NSString*)str;

- (NSInteger)daysBetweenDate:(NSDate*)fromDateTime andDate:(NSDate*)toDateTime;
-(NSString *)randomStringWithLength:(int)len;

@end
