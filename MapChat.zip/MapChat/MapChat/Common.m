//
//  Common.m
//  JoomSocial
//
//  Created by Lion User on 22/02/2013.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "Common.h"
#import "AppDelegate.h"
#import "NSString+HTML.h"


@implementation Common
@synthesize hud,selectedSubcategoryArray,fbDict;

NSString *letters = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        selectedSubcategoryArray = [[NSMutableArray alloc]init];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
 // Implement loadView to create a view hierarchy programmatically, without using a nib.
 - (void)loadView
 {
 }
 */

/*
 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad
 {
 [super viewDidLoad];
 }
 */

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//Show Progress Hud
-(void)showProgressHudWithView:(UIView*)view
{
    hud = [[MBProgressHUD alloc]init];
    hud.delegate = self;
    hud.labelText = @"Loading...";
//    hud.color = [UIColor colorWithWhite:145/255.0f alpha:0.5];
    [hud show:YES];
    [view addSubview:hud];
    
//    [SVProgressHUD showWithStatus:@"Loading..." maskType:app_mask_type];
}
-(void)hideProgressHudWithView:(UIView*)view
{
//      [SVProgressHUD dismiss];
//    [hud hide:YES afterDelay:1];
    [hud hide:YES];
}
-(void)addLogoutButtonToNavigationController:(UINavigationItem*)nav
{
    UIBarButtonItem *logout = [[UIBarButtonItem alloc]initWithTitle:@"Logout" style:UIBarButtonItemStylePlain target:self action:@selector(logout:)];
    nav.rightBarButtonItem = logout;
}
-(IBAction)logout:(id)sender
{
    //    AppDelegate *appDel =(AppDelegate *) [[UIApplication sharedApplication]delegate];
    //    appDel.isLoggedIn=FALSE;
    //    [appDel setAndInitializeViewControllerForTabbarController:self.tabBarController];
}
-(void)addSlectedCategoryDataToArray:(int)parentId
{
    [selectedSubcategoryArray addObject:[NSString stringWithFormat:@"%d",parentId]];
    //    NSLog(@"%@",selectedSubcategoryArray);
}
-(int)getLastSelectedIdOfSubCategory
{
    int i = 0;
    //     NSLog(@"Before Back --> %@",selectedSubcategoryArray);
    if (selectedSubcategoryArray.count>0)
    {
        i = [[selectedSubcategoryArray lastObject]intValue];
        [selectedSubcategoryArray removeLastObject];
    }
    //    NSLog(@"after Back --> %@",selectedSubcategoryArray);
    //    NSLog(@"lsat index --> %d",i);
    return i;
}
-(void)updateScreenSize
{
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    AppDelegate *appDel = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    if (UIInterfaceOrientationIsLandscape(orientation))
    {
//        appDel.screenWidth = screenRect.size.height;
//        appDel.screenHeight = screenRect.size.width;
    }
    else
    {
//        appDel.screenWidth = screenRect.size.width;
//        appDel.screenHeight = screenRect.size.height;
    }
    
}
-(void)shareOnFacebookWithDict:(NSMutableDictionary*)dict
{
    
}
-(UIColor*)setColorWithRGBAWithValuesOfRed:(CGFloat)Red andGreen:(CGFloat)green andBlue:(CGFloat)blue andAlpha:(CGFloat)alpha
{
    UIColor *myColor;
    CGFloat nRed=Red/255.0;
    CGFloat nBlue=green/255.0;
    CGFloat nGreen=blue/255.0;
    if (alpha>=0 && alpha<=1) {
        myColor=[[UIColor alloc]initWithRed:nRed green:nBlue blue:nGreen alpha:alpha];
        
    }else
    {
        myColor=[[UIColor alloc]initWithRed:nRed green:nBlue blue:nGreen alpha:1];
    }
    return myColor;
}


#pragma mark - Custom methods

-(NSString *)convertHtmltoPlainText:(NSString *)String;
{
    NSString *str = [String stringByConvertingHTMLToPlainText];
    str = [self stringByStrippingHTMLWithString:str];
    return str;
}

-(NSString *) stringByStrippingHTMLWithString:(NSString*)str
{
    NSRange r;
    while ((r = [str rangeOfString:@"<[^>]+>" options:NSRegularExpressionSearch]).location != NSNotFound)
        str = [str stringByReplacingCharactersInRange:r withString:@""];
    return str;
}

- (NSInteger)daysBetweenDate:(NSDate*)fromDateTime andDate:(NSDate*)toDateTime
{
    NSDate *fromDate;
    NSDate *toDate;
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    [calendar rangeOfUnit:NSDayCalendarUnit startDate:&fromDate
                 interval:NULL forDate:fromDateTime];
    [calendar rangeOfUnit:NSDayCalendarUnit startDate:&toDate
                 interval:NULL forDate:toDateTime];
    
    NSDateComponents *difference = [calendar components:NSDayCalendarUnit
                                               fromDate:fromDate toDate:toDate options:0];
    
    return [difference day];
}
-(NSString *) randomStringWithLength: (int) len {
    
    NSMutableString *randomString = [NSMutableString stringWithCapacity: len];
    
    for (int i=0; i<len; i++) {
        [randomString appendFormat: @"%C", [letters characterAtIndex: arc4random_uniform([letters length])]];
    }
    
    return randomString;
}
@end
