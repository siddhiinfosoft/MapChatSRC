//
//  WebService.m
//  WebserviceExmpleWithNotification
//
//  Created by kushal shah on 12/15/12.
//  Copyright (c) 2012 Techfreak Developers. All rights reserved.
//
#import "WebService.h"
#import "JSONKit.h"
#import "ASIFormDataRequest.h"
#import "AppDelegate.h"
#import "NSString+HTML.h"

#define VBTQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0) //1
#define NOTIF_DataComplete @"Data Download"
@implementation WebService
@synthesize resultDict,data,delegate;

-(void)sentRequestWithURlString:(NSString*)str
{
//    AppDelegate *appDel = [[UIApplication sharedApplication]delegate];
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:commonUrl,str]];
    NSLog(@"%@",[NSString stringWithFormat:commonUrl,str]);
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    [request setDelegate:self];
    [request startAsynchronous];
}

-(void)sendRequestWithDataDict:(NSMutableDictionary*)dataDict andActionString:(NSString*)action;
{

    data = [[NSMutableData alloc] init];
    NSURL *url;
    ASIFormDataRequest *request;
    NSLog(@"parameters: %@",dataDict);
    //url = [NSURL URLWithString:[NSString stringWithFormat:appDel.WebURL,@"getsearchresult"]];
    url = [NSURL URLWithString:[NSString stringWithFormat:commonUrl,action]];
    request = [ASIFormDataRequest requestWithURL:url];
    [request setDelegate:self];
    NSArray *key = [dataDict allKeys];
    int count = -1;
    for (int i = 0;i<[key count];i++)
    {
        NSString *keyValue = [key objectAtIndex:i];
        NSArray *b = [NSArray arrayWithArray:[keyValue componentsSeparatedByString:@"-"]];
        NSString *key_photo = [b objectAtIndex:0];
//        NSLog(@"%@",key_photo);
        if ([action isEqualToString:@"PhotoSubmit"])
        {
            NSString *fileName  = @"a.png";
            
            // Upload an image
            NSData *imageData = UIImageJPEGRepresentation([UIImage imageNamed:fileName],1.0);
            [request setData:imageData withFileName:fileName andContentType:@"image/jpeg" forKey:@"userfile"];
        }
         else if ([[key objectAtIndex:i] isEqualToString:@"file_Name"])
        {
            //For Update in New Invoice Attachment 
            
            arr_attachment_name=[[NSMutableArray alloc]init];
            
            NSArray *arr  = [dataDict valueForKey:[key objectAtIndex:i]];
            for (int j=0; j<arr.count; j++)
            {
                NSString *str_temp=[arr objectAtIndex:j];
                
                NSArray *arr_component=[str_temp componentsSeparatedByString:@"/"];
                int count=arr_component.count;
                [arr_attachment_name addObject:[arr_component objectAtIndex:count-1]];
            }
            
            NSLog(@"Webservices attachment_name %@",arr_attachment_name);
            
            
        }
        else if ([[key objectAtIndex:i] isEqualToString:@"file"])
        {
            NSString *fileName  = @"a.png";
            /*
            UIImage *img = [dataDict valueForKey:[key objectAtIndex:i]];
            
            if (img==nil || img==NULL) {
                [request setData:nil withFileName:@"" andContentType:@"image/jpeg" forKey:@"file"];
            }
            else{
                NSData *imageData = UIImageJPEGRepresentation(img,1.0);
                [request setData:imageData withFileName:fileName andContentType:@"image/jpeg" forKey:@"file"];
            }*/
            
            
            ///
            NSArray *arr  = [dataDict valueForKey:[key objectAtIndex:i]];
            
            for (int i=0; i<arr.count; i++)
            {
                UIImage *img = [arr objectAtIndex:i];
                
                if (img==nil || img==NULL) {
                    //mitul
                    [request setData:nil withFileName:@"" andContentType:@"image/jpeg" forKey:@"file"];
                    
                }
                else{
                    NSData *imageData = UIImageJPEGRepresentation(img,1.0);
                    
                    if (i==0) {
                        //mitul 16-05-2016 fileName replace [arr_attachment_name objectAtIndex:i]
                        if (arr_attachment_name.count>0)
                        {
                            [request setData:imageData withFileName:[arr_attachment_name objectAtIndex:i] andContentType:@"image/jpeg" forKey:@"file"];
                        }
                        else
                        {
                            [request setData:imageData withFileName:fileName andContentType:@"image/jpeg" forKey:@"file"];
                        }
                        
                    }else{
                        //mitul 16-05-2016 fileName replace [arr_attachment_name objectAtIndex:i]
                        if (arr_attachment_name.count>0)
                        {
                            [request setData:imageData withFileName:[arr_attachment_name objectAtIndex:i] andContentType:@"image/jpeg" forKey:[NSString stringWithFormat:@"file%d",i]];
                        }
                        else
                        {
                            [request setData:imageData withFileName:fileName andContentType:@"image/jpeg" forKey:[NSString stringWithFormat:@"file%d",i]];
                        }
                    }
                    
                    
                    
                }
            }
            //change mitul
//            if (arrGetData.count==0)
//            {
//                //change mitul
////                [request setData:nil withFileName:@"" andContentType:@"image/jpeg" forKey:@"file"];
//            }
//            else
//            {
//                [request setData:[arrGetData componentsJoinedByString:@","] withFileName:fileName andContentType:@"image/jpeg" forKey:@"file"];
//            }
            
            ///
        }
        
        else if ([[key objectAtIndex:i] isEqualToString:@"image_name1"])
        {
            NSString *fileName  = [dataDict valueForKey:@"a"];
            NSData *imageData = UIImageJPEGRepresentation([dataDict valueForKey:[key objectAtIndex:i]],1.0);
            NSString *type = [self contentTypeForImageData:imageData];
            
            if(fileName.length>0)
            {
                
                [request setData:imageData withFileName:fileName andContentType:@"image/jpeg" forKey:@"image_name"];
            }
            else
            {
                fileName = [NSString stringWithFormat:@"%@.%@",[NSDate date],[[type componentsSeparatedByString:@"/"] objectAtIndex:1]];
                [request setData:imageData withFileName:fileName andContentType:@"image/jpeg" forKey:@"image_name"];
                
            }
            
        }
        
        
        else if ([action isEqualToString:@"setMyGallaryDashboardPhase2"]&&[key_photo isEqualToString:@"image"])
        {
            count++;
            NSString *fileName  = [NSString stringWithFormat:@"a%d.png",count];
            NSString *strKey = [NSString stringWithFormat:@"image_name[%d]",count];
            // Upload an image
//            NSLog(@"%@",keyValue);
//            NSLog(@"%@",[dataDict valueForKey:keyValue]);
            UIImage *img = [dataDict valueForKey:keyValue];
            NSData *imageData = UIImageJPEGRepresentation(img,1.0);
            
            [request setData:imageData withFileName:fileName andContentType:@"image/jpeg" forKey:strKey];
        }
        else
        {
            [request setPostValue:[dataDict valueForKey:[key objectAtIndex:i]] forKey:[key objectAtIndex:i]];
        }
    }
     [request startAsynchronous];
}
- (void)requestFinished:(ASIHTTPRequest *)request
{
    NSLog(@"%@",request);
    NSLog(@"%@",[[request responseString] objectFromJSONString]);
    [[self delegate]onFinishLodingWithDictionary:[[request responseString] objectFromJSONString]];
}
- (void)requestFailed:(ASIHTTPRequest *)request
{
    [[self delegate]onFinishLodingWithError:[request error].localizedDescription];
}

-(BOOL) validateEmail: (NSString *) email {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}
-(NSString*)convertDateFormateFormCurrentFormate:(NSString*)currentFormate toNewFormate:(NSString*)newFormate withDate:(NSString*)dateString
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:currentFormate];
    NSDate *date = [formatter dateFromString:dateString];
    
    NSDateFormatter *f = [[NSDateFormatter alloc]init];
    [f setDateFormat:newFormate];
    return [f stringFromDate:date];
}

-(NSString *)convertHtmltoPlainText:(NSString *)String  
{
    NSString *str = [String stringByConvertingHTMLToPlainText];
    str = [self stringByStrippingHTMLWithString:str];
    return str;
}

-(NSString *) stringByStrippingHTMLWithString:(NSString*)str {
    NSRange r;
    while ((r = [str rangeOfString:@"<[^>]+>" options:NSRegularExpressionSearch]).location != NSNotFound)
        str = [str stringByReplacingCharactersInRange:r withString:@""];
    return str;
}

-(NSString *)convertPlainTextToHtmlTag:(NSString*)str {
    
    str = [str stringByDecodingHTMLEntities];
    return str;
}



-(BOOL)isNullObject:(NSString*)str
{
    BOOL isNullObject = FALSE;
    
    if ([str isKindOfClass:[NSNull class]]|| str==NULL)
    {
        isNullObject = TRUE;
    }
    return isNullObject;
}

-(NSString *)contentTypeForImageData:(NSData *)image_data{
    uint8_t c;
    [image_data getBytes:&c length:1];
    
    switch (c) {
        case 0xFF:
            return @"image/jpeg";
        case 0x89:
            return @"image/png";
        case 0x47:
            return @"image/gif";
        case 0x49:
        case 0x4D:
            return @"image/tiff";
    }
    return nil;
}

@end
