//
//  TabBarController.h
//  MapChat
//
//  Created by Vishal Tanna on 31/05/16.
//  Copyright © 2016 SiddhiInfosoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabBarController : UITabBarController

@end
